result = 1;
